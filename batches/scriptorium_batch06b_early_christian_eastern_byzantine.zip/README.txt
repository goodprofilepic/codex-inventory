SCRIPTORIUM BATCH 06B — DEDUPLICATED, ONE-ENTRY-PER-WORK VERSION

Contains 8 individual Reading Room records:
- On Easter, or, The Paschal Cycle — Dionysius Exiguus (11,428 words)
- Letter to Shenouda concerning an Origenist Monk — Dioscorus of Alexandria (1,150 words)
- Against the Forgeries of the Apollinarists — Leontius of Byzantium (10,447 words)
- The Life of Saint Severinus — Eugippius (18,412 words)
- A Commonitory — Vincent of Lérins (19,509 words)
- On Heresies — John of Damascus (John Damascene) (15,668 words)
- The Philosophical Chapters — John of Damascus (John Damascene) (32,937 words)
- Ecclesiastical History, Part III (Surviving Books II and V Continuation) — John of Ephesus (25,065 words)

The earlier staged version of this ZIP included An Exact Exposition of the Orthodox Faith, Books I–IV. A live Reading Room query found all four books already published and complete under John of Damascus, with the same source URLs. That duplicate work has been entirely removed from this replacement archive.

John of Damascus's On Heresies and The Philosophical Chapters remain separate entries because no matching records for those titles appeared in that live query.

John of Ephesus's Book II and the surviving continuation of Book V have been combined into a single partial-work entry, not two separate works. The text labels the gap and begins Book V at the surviving continuation (chapter XIII).

Every TXT file contains Scriptorium's ten metadata fields. Historical chapter headings are retained. No file in this package has been uploaded or published to the live Reading Room. The importer's duplicate guard should still be used.
