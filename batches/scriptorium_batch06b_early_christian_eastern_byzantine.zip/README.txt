SCRIPTORIUM BATCH 06B — COMBINED WORKS VERSION

This revised archive replaces the earlier 13-file layout with 9 distinct work records (one TXT per work):
- On Easter, or, The Paschal Cycle — Dionysius Exiguus (11,428 words)
- Letter to Shenouda concerning an Origenist Monk — Dioscorus of Alexandria (1,150 words)
- Against the Forgeries of the Apollinarists — Leontius of Byzantium (10,447 words)
- The Life of Saint Severinus — Eugippius (18,412 words)
- A Commonitory — Vincent of Lérins (19,509 words)
- On Heresies — John of Damascus (John Damascene) (15,668 words)
- The Philosophical Chapters — John of Damascus (John Damascene) (32,937 words)
- Ecclesiastical History, Part III (Surviving Books II and V Continuation) — John of Ephesus (25,065 words)
- An Exact Exposition of the Orthodox Faith — John of Damascus (79,326 words)

Structural correction:
- John of Damascus's four books of An Exact Exposition are combined into one complete work record with Book I–IV headings.
- John of Ephesus's surviving Book II and the available continuation of Book V are combined into one incomplete-work record, with the gap clearly labeled. Book V begins at chapter XIII in this surviving source.
- The other seven works remain separate records.

No source text has been invented or reconstructed. Original internal headings and divisions have been retained. Every TXT contains the ten Scriptorium metadata fields.
Nothing has been uploaded or published to the live Reading Room.
The live catalogue duplicate query was unavailable due to the Lovable free-plan action limit. Run the Reading Room importer's own duplicate check before accepting drafts.
