SCRIPTORIUM BATCH 06B — EARLY CHRISTIAN, SYRIAC, COPTIC, AND BYZANTINE WORKS

Contains 13 individual Reading Room texts:
- On Easter, or, The Paschal Cycle — Dionysius Exiguus (11,428 words)
- Letter to Shenouda concerning an Origenist Monk — Dioscorus of Alexandria (1,150 words)
- Ecclesiastical History, Part III, Book II — John of Ephesus (21,741 words)
- Ecclesiastical History, Part III, Book V (Surviving Continuation) — John of Ephesus (3,522 words)
- Against the Forgeries of the Apollinarists — Leontius of Byzantium (10,422 words)
- The Life of Saint Severinus — Eugippius (18,412 words)
- A Commonitory — Vincent of Lérins (19,509 words)
- An Exact Exposition of the Orthodox Faith, Book I — John of Damascus (John Damascene) (12,365 words)
- An Exact Exposition of the Orthodox Faith, Book II — John of Damascus (John Damascene) (21,061 words)
- An Exact Exposition of the Orthodox Faith, Book III — John of Damascus (John Damascene) (23,009 words)
- An Exact Exposition of the Orthodox Faith, Book IV — John of Damascus (John Damascene) (22,891 words)
- On Heresies — John of Damascus (John Damascene) (15,668 words)
- The Philosophical Chapters — John of Damascus (John Damascene) (32,937 words)

Editorial and rights notes:
- Each TXT has all ten Scriptorium metadata fields at the top.
- John of Ephesus Book V is only a surviving continuation; the first twelve chapters are not included in this source and the title/description make that clear.
- The Life of Saint Severinus is the 1914 George W. Robinson English translation, now public domain in the United States.
- John of Damascus's Books I–IV are kept as separate original book divisions; On Heresies and The Philosophical Chapters are separate treatises.
- The John of Damascus translations by Frederic H. Chase Jr. (1958) are marked public domain in the United States because the source states the copyright was not renewed.
- Vincent of Lerins's translator introduction and footnotes have been omitted.
- All text is extracted from source transcriptions; no missing manuscript material has been reconstructed.

Duplicate screening:
The current Lovable database query action has reached its free-plan limit, so a new exact-title query was unavailable. The selected author folders were not present in the previously queried live author inventory, but the Reading Room importer's own duplicate check should be treated as final before accepting drafts.

No file in this ZIP has been published or inserted into the live Reading Room.
