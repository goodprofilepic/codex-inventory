SCRIPTORIUM — AUTHOR EXPANSION BATCH 05
======================================

This batch contains 10 individual works by 9 author identities that were not found in the available 2026-10-25 catalogue snapshot.

Included authors:
- Rabbula of Edessa
- Philostorgius
- Severus of Antioch
- Venantius Fortunatus
- Eusebius of Emesa
- Theognostus of Alexandria
- John of Epiphania
- Severian of Gabala
- Macarius Magnes

Editorial and completeness notes:
- Every text has Scriptorium's ten metadata fields at the top.
- Each work is an individual import record, not one combined anthology.
- Existing book, chapter, letter, sermon, and section headings are retained.
- Introductions and printed footnote apparatus have generally been removed from the main text.
- The two Severus works are separate texts by the same newly identified author.
- Theognostus's seven-book Hypotyposes survives only in the three fragments included here.
- John of Epiphania's history survives only in its opening five chapters and breaks off during chapter five.
- The Apocriticus survives in an incomplete manuscript; its description identifies the surviving sections and gaps.
- The older attribution of the Passion homily to Severian was corrected by the online editor to Eusebius of Emesa using the Clavis Patrum Graecorum.
- The Venantius poem has two obvious transcription errors corrected; the historic translation is otherwise preserved.

Duplicate screening:
- Compared title/author pairs with the available 2,177-line catalogue snapshot in codex_titles.txt (export dated 2026-10-25).
- No exact title/author pairs were found in that snapshot.
- This is not a current live-catalogue confirmation. The Lovable database-query service has reached its free-plan action limit, so the Reading Room importer's own duplicate guard should run before these are accepted as drafts, particularly for material added after 2026-10-25.

Rights:
- Each text carries its source edition and rights note in its own metadata.
- The batch excludes recent translations without a clear public-domain release statement.
- Texts whose surviving manuscripts are incomplete are labeled as such; no missing sections have been reconstructed.

Import status:
- These files are prepared for import only.
- Nothing has been published or inserted into the live Reading Room by this batch.
