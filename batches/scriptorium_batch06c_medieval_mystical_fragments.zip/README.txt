SCRIPTORIUM BATCH 06C — MEDIEVAL, MYSTICAL, AND HETERODOX CHRISTIAN TEXTS

Contains four separate source texts:
- Religious Discussion at the Court of the Sassanids (De Gestis in Perside) — Anonymous Christian author (text preserved with fragments attributed to Philip of Side) (16,711 words)
- Excerpts of Theodotus: Selections from the Prophetic Scriptures — Anonymous compiler (traditionally attributed to Theodotus; identity uncertain) (6,558 words)
- Dark Night of the Soul — John of the Cross (53,540 words)
- Exposition on the Seven Visions of the Book of Revelation — Berengaudus (120,108 words)

Attribution and completeness:
- The Religious Discussion at the Court of the Sassanids is catalogued as anonymous. Only some portions are identified by the editor as fragments or probable references connected with Philip of Side.
- The Excerpts of Theodotus are an uncertain compilation transmitted under that name. The translator/editor notes that the compiler's identity is not secure and that several historical Theodotuses could be involved; this is not specifically attributed to Theodotus of Ancyra.
- Dark Night of the Soul is E. Allison Peers's English translation. The source says CCEL's scan of the 1959 Image Books edition is uncopyrighted; the rights note is limited to the United States/source edition.
- Berengaudus's commentary begins with the translated exposition proper; the translator's introduction has been left out.

All four TXT files contain Scriptorium's ten metadata fields. No files have been uploaded or published to the live Reading Room by this package.
