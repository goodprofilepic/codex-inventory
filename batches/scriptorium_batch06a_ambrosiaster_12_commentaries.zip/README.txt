SCRIPTORIUM BATCH 06A — AMBRO SIASTER COMMENTARIES

This package contains 12 separate, complete commentaries by Ambrosiaster on Pauline epistles:
- Commentary on 1 Corinthians
- Commentary on 1 Thessalonians
- Commentary on 1 Timothy
- Commentary on 2 Corinthians
- Commentary on 2 Thessalonians
- Commentary on 2 Timothy
- Commentary on Colossians
- Commentary on Ephesians
- Commentary on Galatians
- Commentary on Philemon
- Commentary on Philippians
- Commentary on Titus

Author note:
Ambrosiaster is the conventional name for an anonymous Roman Christian commentator active around AD 366–384. The works were long printed under Ambrose's name but are not by Ambrose of Milan. Each is catalogued under the conventional author name Ambrosiaster.

Translation and rights:
All 12 source pages explicitly state that John Litteral's English translations are released into the public domain. The underlying Latin is the Maurist edition (1690), as printed in Patrologia Latina 17 (1845). Each file repeats its own source and rights metadata.

Editorial handling:
- The translator's source note and footnote apparatus are excluded from the Reading Room text.
- Prologues, chapter headings, biblical lemmata, and explanatory commentary are retained.
- One commentary per TXT file; do not merge these 12 works into one anthology.

Duplicate note:
The live Scriptorium database action limit prevented a fresh exact-title query in this turn. The live author inventory previously checked did not show Ambrosiaster as an existing author; nonetheless, run the importer's final duplicate check before accepting drafts.

No file in this package has been uploaded to or published in the live Reading Room.
